#!/usr/bin/env bash
# Builds the BlackBox virtual-engine AAR and copies it to app/libs so the app gets real "hide app" support.
#
# Needs: git, JDK 21 (the engine is written for Java 21), the Android SDK (ANDROID_HOME set) and the NDK version the engine asks for
# (its README currently says NDK 29.0.13846066; install it in Android Studio > SDK Manager > SDK Tools).
#
#   ./scripts/build_engine.sh                      # uses ALEX5402/NewBlackbox
#   ENGINE_REPO=<git url> ENGINE_MODULE=BCore ./scripts/build_engine.sh
set -euo pipefail

REPO="${ENGINE_REPO:-https://github.com/ALEX5402/NewBlackbox.git}"
MODULE="${ENGINE_MODULE:-Bcore}"     # some forks spell it BCore
HERE="$(cd "$(dirname "$0")" && pwd)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

git clone --depth 1 --recurse-submodules --shallow-submodules "$REPO" "$WORK/engine"
cd "$WORK/engine"
chmod +x ./gradlew

# Forks spell the core module Bcore / BCore / bcore: use whichever folder actually exists.
found="$(find . -mindepth 1 -maxdepth 1 -type d -iname "$MODULE" | head -n 1)"
if [ -z "$found" ]; then
  echo "Could not find a module called '$MODULE' in $REPO. Folders in the repo:"
  find . -mindepth 1 -maxdepth 1 -type d -not -name '.*' | sed 's|^\./|  |'
  echo "Set ENGINE_MODULE to the right one and run again."
  exit 1
fi
MODULE="$(basename "$found")"
echo "Building engine module :$MODULE from $REPO"

./gradlew ":${MODULE}:assembleRelease" --stacktrace

# An AAR does not carry the libraries its module depends on. Print them so a "class not found" failure when the
# engine starts inside the app can be traced to the missing library.
echo "---- :${MODULE} runtime dependencies ----"
./gradlew ":${MODULE}:dependencies" --configuration releaseRuntimeClasspath -q 2>&1 | head -n 150 || true
echo "---- end of dependencies ----"

AAR="$(find "$MODULE" -path '*outputs/aar/*' -name '*release*.aar' | head -n 1)"
if [ -z "$AAR" ]; then
  # Some forks name it differently (no "release" in the file name): take any AAR the build produced.
  AAR="$(find "$MODULE" -path '*outputs/aar/*' -name '*.aar' | head -n 1)"
fi
if [ -z "$AAR" ]; then
  echo "No AAR found under $MODULE/build/outputs/aar. Files the build produced:"
  find "$MODULE" -path '*build/outputs*' -type f | head -n 40
  exit 1
fi

LIBS="$HERE/../app/libs"
mkdir -p "$LIBS"
rm -f "$LIBS"/engine-dep-*.jar
cp "$AAR" "$LIBS/blackbox-core.aar"

# The AAR does not contain the libraries the engine depends on (BlackReflection etc.). Export them as jars next
# to it, otherwise the engine fails to start in the app with NoClassDefFoundError.
echo "---- exporting the engine's library dependencies ----"
ENGINE_MODULE_NAME="$MODULE" ENGINE_DEPS_OUT="$LIBS" \
  ./gradlew -I "$HERE/export-engine-deps.init.gradle" ":${MODULE}:exportEngineDeps" --stacktrace

# Fail now, with a clear message, if the class from the crash report is still not available anywhere.
CLASS="top/niunaijun/blackreflection/BlackReflection.class"
found=0
for f in "$LIBS"/blackbox-core.aar "$LIBS"/engine-dep-*.jar; do
  [ -f "$f" ] || continue
  if [ "${f##*.}" = "aar" ]; then
    unzip -p "$f" classes.jar > "$WORK/core-classes.jar" 2>/dev/null && unzip -l "$WORK/core-classes.jar" | grep -q "$CLASS" && found=1
  else
    unzip -l "$f" | grep -q "$CLASS" && found=1
  fi
done
if [ "$found" != 1 ]; then
  echo "ERROR: $CLASS is not in the engine AAR or in the exported libraries."
  echo "Look at the dependency list printed above and find where BlackReflection comes from (a JitPack artifact or a"
  echo "module of the engine repo), then add it to the export. The app will crash at engine start without it."
  exit 1
fi

echo "Copied the engine AAR and its libraries to app/libs:"
ls -l "$LIBS"
echo "Now rebuild the app."
