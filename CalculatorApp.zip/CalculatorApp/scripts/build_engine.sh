#!/usr/bin/env bash
# Builds the BlackBox virtual-engine AAR and copies it to app/libs so the app gets real "hide app" support.
#
# Needs: git, JDK 17, the Android SDK (ANDROID_HOME set) and the NDK version the engine asks for
# (its README currently says NDK 29.0.13846066; install it in Android Studio > SDK Manager > SDK Tools).
#
#   ./scripts/build_engine.sh                      # uses ALEX5402/NewBlackbox
#   ENGINE_REPO=<git url> ENGINE_MODULE=BCore ./scripts/build_engine.sh
set -euo pipefail

REPO="${ENGINE_REPO:-https://github.com/ALEX5402/NewBlackbox.git}"
MODULE="${ENGINE_MODULE:-Bcore}"     # some forks spell it BCore
HERE="$(cd "$(dirname "$0")" && pwd)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

git clone --depth 1 "$REPO" "$WORK/engine"
cd "$WORK/engine"
chmod +x ./gradlew
./gradlew ":${MODULE}:assembleRelease"

AAR="$(find "$MODULE" -path '*outputs/aar/*' -name '*release*.aar' | head -n 1)"
[ -n "$AAR" ] || { echo "No release AAR found under $MODULE/build/outputs/aar"; exit 1; }

mkdir -p "$HERE/../app/libs"
cp "$AAR" "$HERE/../app/libs/blackbox-core.aar"
echo "Copied $(basename "$AAR") to app/libs/blackbox-core.aar. Now rebuild the app."
