#!/usr/bin/env bash
# Builds the BlackBox virtual-engine AAR and copies it to app/libs so the app gets real "hide app" support.
#
# Needs: git, JDK 17, the Android SDK (ANDROID_HOME set) and the NDK version the engine asks for
# (its README currently says NDK 29.0.13846066; install it in Android Studio > SDK Manager > SDK Tools).
#
#   ./scripts/build_engine.sh                      # uses ALEX5402/NewBlackbox
#   ENGINE_REPO=<git url> ENGINE_MODULE=BCore ./scripts/build_engine.sh
set -euo pipefail

REPO="${ENGINE_REPO:-https://github.com/ALEX5402/NewBlackbox.git}"
MODULE="${ENGINE_MODULE:-Bcore}"     # some forks spell it BCore
HERE="$(cd "$(dirname "$0")" && pwd)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

git clone --depth 1 --recurse-submodules --shallow-submodules "$REPO" "$WORK/engine"
cd "$WORK/engine"
chmod +x ./gradlew

# Forks spell the core module Bcore / BCore / bcore: use whichever folder actually exists.
found="$(find . -mindepth 1 -maxdepth 1 -type d -iname "$MODULE" | head -n 1)"
if [ -z "$found" ]; then
  echo "Could not find a module called '$MODULE' in $REPO. Folders in the repo:"
  find . -mindepth 1 -maxdepth 1 -type d -not -name '.*' | sed 's|^\./|  |'
  echo "Set ENGINE_MODULE to the right one and run again."
  exit 1
fi
MODULE="$(basename "$found")"
echo "Building engine module :$MODULE from $REPO"

./gradlew ":${MODULE}:assembleRelease" --stacktrace

AAR="$(find "$MODULE" -path '*outputs/aar/*' -name '*release*.aar' | head -n 1)"
if [ -z "$AAR" ]; then
  # Some forks name it differently (no "release" in the file name): take any AAR the build produced.
  AAR="$(find "$MODULE" -path '*outputs/aar/*' -name '*.aar' | head -n 1)"
fi
if [ -z "$AAR" ]; then
  echo "No AAR found under $MODULE/build/outputs/aar. Files the build produced:"
  find "$MODULE" -path '*build/outputs*' -type f | head -n 40
  exit 1
fi

mkdir -p "$HERE/../app/libs"
cp "$AAR" "$HERE/../app/libs/blackbox-core.aar"
echo "Copied $(basename "$AAR") to app/libs/blackbox-core.aar. Now rebuild the app."
