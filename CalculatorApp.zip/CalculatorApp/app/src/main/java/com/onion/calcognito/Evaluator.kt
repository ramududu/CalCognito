package com.onion.calcognito

import java.math.BigDecimal
import java.math.BigInteger
import java.math.MathContext
import java.math.RoundingMode
import kotlin.math.*

object Evaluator {

    @Volatile
    var degrees: Boolean = true

    /** Hard ceiling on significant digits for scrolling irrational results (was 1200). */
    const val MAX_DIGITS = 100_000

    // The digit caches are shared between the UI thread and the background digit worker.
    // The lock only guards reading/writing the cache; the heavy maths runs outside it.
    private val cacheLock = Any()

    /** Lets a background computation be abandoned promptly when the caller interrupts its thread. */
    private fun checkCancel() {
        if (Thread.currentThread().isInterrupted) throw InterruptedException("cancelled")
    }

    private var cachedPiPrecision = 0
    private var cachedPi: BigDecimal = BigDecimal.ZERO
    private var cachedEPrecision = 0
    private var cachedE: BigDecimal = BigDecimal.ZERO

    fun eval(expr: String): Double {
        val cleaned = applyContextPercent(normalize(expr))
        val p = Parser(cleaned)
        val v = p.parseExpression()
        if (p.pos < cleaned.length) throw IllegalArgumentException("Format error")
        if (v.isNaN()) throw ArithmeticException("Can't calculate")
        if (v.isInfinite()) throw ArithmeticException("Value too large")
        return v
    }

    fun format(v: Double): String {
        if (v.isInfinite() || abs(v) > 1e308) throw ArithmeticException("Value too large")
        val s = if (v == Math.floor(v) && Math.abs(v) < 1e15) v.toLong().toString()
        else BigDecimal(v).round(MathContext(12)).stripTrailingZeros().toPlainString()
        return if (s == "-0") "0" else s.replace('-', '−')
    }

    fun formatExpr(expr: String): String {
        val d = eval(expr)
        if (abs(d) >= 1e15) {
            try {
                val big = evalBig(expr, 330)
                if (!big.contains('.')) return big
            } catch (_: Exception) {}
        }
        return format(d)
    }

    fun evalBig(expr: String, precision: Int = 35): String {
        val safePrec = precision.coerceIn(16, MAX_DIGITS)
        val cleaned = applyContextPercent(normalize(expr))
        val workMc = MathContext(safePrec + 8, RoundingMode.HALF_UP)
        val p = BigParser(cleaned, workMc)
        val v = p.parseExpression()
        if (p.pos < cleaned.length) throw IllegalArgumentException("Format error")
        if (v.abs() > BigDecimal("1E308")) throw ArithmeticException("Value too large")
        val rounded = v.round(MathContext(safePrec, RoundingMode.HALF_UP)).stripTrailingZeros()
        val s = rounded.toPlainString()
        return if (s == "-0") "0" else s.replace('-', '−')
    }

    fun hasInfiniteDecimals(expr: String): Boolean {
        return try {
            val r1 = evalBig(expr, 20)
            val r2 = evalBig(expr, 35)
            r1.contains('.') && r2.contains('.') && r2.length > r1.length + 5
        } catch (e: Exception) {
            false
        }
    }

    private fun normalize(expr: String): String =
        expr.replace("arcsin", "asin").replace("arccos", "acos").replace("arctan", "atan")

    private val percentRegex = Regex("(?<=[0-9.)])([+−-])([0-9.]+)%")

    /** Index where the operand that ends just before [opIdx] starts: a number, or a (...) group with its function name. */
    private fun leftOperandStart(s: String, opIdx: Int): Int {
        var i = opIdx - 1
        if (i < 0) return -1
        if (s[i] == ')') {
            var depth = 0
            while (i >= 0) {
                if (s[i] == ')') depth++
                else if (s[i] == '(') {
                    depth--
                    if (depth == 0) break
                }
                i--
            }
            if (i < 0) return -1
            while (i > 0 && s[i - 1].isLetter()) i--
            return i
        }
        while (i >= 0 && (s[i].isDigit() || s[i] == '.')) i--
        return i + 1
    }

    private fun applyContextPercent(expr: String): String {
        var result = expr
        var guard = 0
        while (guard++ < 20) {
            val m = percentRegex.find(result) ?: break
            val opIdx = m.range.first
            val start = leftOperandStart(result, opIdx)
            if (start < 0) break
            val a = result.substring(start, opIdx)
            val op = m.groupValues[1]
            val b = m.groupValues[2]
            val replacement = "$a$op($a×($b÷100))"
            result = result.substring(0, start) + replacement + result.substring(m.range.last + 1)
        }
        return result
    }

    private class Parser(val s: String) {
        var pos = 0
        private fun peek(): Char? = if (pos < s.length) s[pos] else null
        private fun startsWith(tok: String) = s.regionMatches(pos, tok, 0, tok.length)

        fun parseExpression(): Double {
            var v = parseTerm()
            while (true) {
                when (peek()) {
                    '+' -> { pos++; v += parseTerm() }
                    '−', '-' -> { pos++; v -= parseTerm() }
                    else -> return v
                }
            }
        }

        private fun parseSigned(): Double = when (peek()) {
            '−', '-' -> { pos++; -parseSigned() }
            '+' -> { pos++; parseSigned() }
            else -> parsePower()
        }

        private fun parseTerm(): Double {
            var v = parseSigned()
            while (true) {
                val c = peek()
                when {
                    c == '×' -> { pos++; v *= parseSigned() }
                    c == '÷' -> {
                        pos++
                        val d = parseSigned()
                        if (d == 0.0) throw ArithmeticException("Can't divide by 0")
                        v /= d
                    }
                    c == '(' || (c != null && (c.isLetter() || c.isDigit() || c == '.')) || c == 'π' || c == '√' -> v *= parsePower()
                    else -> return v
                }
            }
        }

        private fun parsePower(): Double {
            val base = parsePostfix()
            if (peek() == '^') {
                pos++
                val exp = parseSigned()
                val res = base.pow(exp)
                if (res.isNaN()) throw ArithmeticException("Can't calculate")
                if (res.isInfinite()) throw ArithmeticException("Value too large")
                return res
            }
            return base
        }

        private fun parseUnary(): Double = when (peek()) {
            '−', '-' -> { pos++; -parseUnary() }
            '+' -> { pos++; parseUnary() }
            else -> parsePostfix()
        }

        private fun parsePostfix(): Double {
            var v = parsePrimary()
            while (true) {
                when (peek()) {
                    '%' -> { pos++; v /= 100.0 }
                    '!' -> { pos++; v = factorial(v) }
                    '²' -> { pos++; v *= v }
                    else -> return v
                }
            }
        }

        private fun factorial(x: Double): Double {
            if (x < 0 || x != Math.floor(x)) throw ArithmeticException("Can't calculate")
            if (x > 170) throw ArithmeticException("Value too large")
            var r = 1.0
            var i = 2
            while (i <= x.toInt()) { r *= i; i++ }
            return r
        }

        private val funcs = listOf("asin", "acos", "atan", "sin", "cos", "tan", "ln", "log", "sqrt")

        private fun parsePrimary(): Double {
            if (peek() == '(') {
                pos++
                val v = parseExpression()
                if (peek() == ')') pos++
                return v
            }
            if (startsWith("π")) { pos++; return Math.PI }
            if (startsWith("√")) { pos++; return sqrt(parsePostfixArgForFunction()) }
            for (f in funcs) {
                if (startsWith(f)) {
                    pos += f.length
                    val arg = parsePostfixArgForFunction()
                    return applyFunc(f, arg)
                }
            }
            if (peek() == 'e' && !(pos + 1 < s.length && s[pos + 1].isLetter())) {
                pos++; return Math.E
            }
            val start = pos
            while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
            if (start == pos) throw IllegalArgumentException("Format error")
            return s.substring(start, pos).toDouble()
        }

        private fun parsePostfixArgForFunction(): Double {
            return if (peek() == '(') parsePrimary() else parseUnary()
        }

        /** sin/cos/tan of an angle in degrees; exact for the usual special angles. */
        private fun trigDeg(name: String, x: Double): Double {
            var a = x % 360.0
            if (a < 0) a += 360.0
            if (name == "sin") {
                var sign = 1.0
                if (a >= 180.0) { a -= 180.0; sign = -1.0 }
                if (a > 90.0) a = 180.0 - a
                val r = if (a == 0.0) 0.0 else if (a == 30.0) 0.5 else if (a == 90.0) 1.0 else sin(Math.toRadians(a))
                return sign * r
            }
            if (name == "cos") {
                if (a > 180.0) a = 360.0 - a
                var sign = 1.0
                if (a > 90.0) { a = 180.0 - a; sign = -1.0 }
                val r = if (a == 90.0) 0.0 else if (a == 60.0) 0.5 else if (a == 0.0) 1.0 else cos(Math.toRadians(a))
                return sign * r
            }
            a %= 180.0
            if (a == 0.0) return 0.0
            if (a == 90.0) throw ArithmeticException("Can't calculate")
            if (a == 45.0) return 1.0
            if (a == 135.0) return -1.0
            return if (a > 90.0) -tan(Math.toRadians(180.0 - a)) else tan(Math.toRadians(a))
        }

        /** Rounding noise such as sin(π) = 1.2e-16 is shown as 0. */
        private fun snapTiny(r: Double, x: Double): Double =
            if (abs(x) >= 1.0 && abs(r) < 4e-16 * abs(x)) 0.0 else r

        private fun trigRad(name: String, x: Double): Double = when (name) {
            "sin" -> snapTiny(sin(x), x)
            "cos" -> snapTiny(cos(x), x)
            else -> {
                if (snapTiny(cos(x), x) == 0.0) throw ArithmeticException("Can't calculate")
                tan(x)
            }
        }

        private fun applyFunc(name: String, x: Double): Double {
            val r = when (name) {
                "sin", "cos", "tan" -> if (degrees) trigDeg(name, x) else trigRad(name, x)
                "asin" -> if (degrees) Math.toDegrees(asin(x)) else asin(x)
                "acos" -> if (degrees) Math.toDegrees(acos(x)) else acos(x)
                "atan" -> if (degrees) Math.toDegrees(atan(x)) else atan(x)
                "ln" -> ln(x)
                "log" -> log10(x)
                "sqrt" -> sqrt(x)
                else -> throw IllegalArgumentException("Format error")
            }
            if (r.isNaN()) throw ArithmeticException("Can't calculate")
            if (r.isInfinite()) throw ArithmeticException(if (name == "ln" || name == "log") "Can't calculate" else "Value too large")
            return r
        }
    }

    private class BigParser(val s: String, val mc: MathContext) {
        var pos = 0
        private fun peek(): Char? = if (pos < s.length) s[pos] else null
        private fun startsWith(tok: String) = s.regionMatches(pos, tok, 0, tok.length)

        fun parseExpression(): BigDecimal {
            var v = parseTerm()
            while (true) {
                when (peek()) {
                    '+' -> { pos++; v = v.add(parseTerm(), mc) }
                    '−', '-' -> { pos++; v = v.subtract(parseTerm(), mc) }
                    else -> return v
                }
            }
        }

        private fun parseSigned(): BigDecimal = when (peek()) {
            '−', '-' -> { pos++; parseSigned().negate(mc) }
            '+' -> { pos++; parseSigned() }
            else -> parsePower()
        }

        private fun parseTerm(): BigDecimal {
            var v = parseSigned()
            while (true) {
                val c = peek()
                when {
                    c == '×' -> { pos++; v = v.multiply(parseSigned(), mc) }
                    c == '÷' -> {
                        pos++
                        val d = parseSigned()
                        if (d.compareTo(BigDecimal.ZERO) == 0) throw ArithmeticException("Can't divide by 0")
                        v = v.divide(d, mc)
                    }
                    c == '(' || (c != null && (c.isLetter() || c.isDigit() || c == '.')) || c == 'π' || c == '√' ->
                        v = v.multiply(parsePower(), mc)
                    else -> return v
                }
            }
        }

        private fun parsePower(): BigDecimal {
            val base = parsePostfix()
            if (peek() == '^') {
                pos++
                val exp = parseSigned()
                val intExp = exp.toInt()
                if (exp.compareTo(BigDecimal(intExp)) == 0 && abs(intExp) <= 9999) {
                    return base.pow(intExp, mc)
                }
                return bigExp(exp.multiply(bigLn(base, mc), mc), mc)
            }
            return base
        }

        private fun parseUnary(): BigDecimal = when (peek()) {
            '−', '-' -> { pos++; parseUnary().negate(mc) }
            '+' -> { pos++; parseUnary() }
            else -> parsePostfix()
        }

        private fun parsePostfix(): BigDecimal {
            var v = parsePrimary()
            while (true) {
                when (peek()) {
                    '%' -> { pos++; v = v.divide(BigDecimal(100), mc) }
                    '!' -> { pos++; v = bigFactorial(v) }
                    '²' -> { pos++; v = v.multiply(v, mc) }
                    else -> return v
                }
            }
        }

        private fun bigFactorial(x: BigDecimal): BigDecimal {
            val n = x.toInt()
            if (x.compareTo(BigDecimal(n)) != 0 || n < 0) throw ArithmeticException("Can't calculate")
            if (n > 170) throw ArithmeticException("Value too large")
            var r = BigDecimal.ONE
            for (i in 2..n) r = r.multiply(BigDecimal.valueOf(i.toLong()), mc)
            return r
        }

        private val funcs = listOf("asin", "acos", "atan", "sin", "cos", "tan", "ln", "log", "sqrt")

        private fun parsePrimary(): BigDecimal {
            if (peek() == '(') {
                pos++
                val v = parseExpression()
                if (peek() == ')') pos++
                return v
            }
            if (startsWith("π")) { pos++; return computePi(mc.precision) }
            if (startsWith("√")) { pos++; return bigSqrt(parsePostfixArgForFunction(), mc) }
            for (f in funcs) {
                if (startsWith(f)) {
                    pos += f.length
                    val arg = parsePostfixArgForFunction()
                    return applyBigFunc(f, arg)
                }
            }
            if (peek() == 'e' && !(pos + 1 < s.length && s[pos + 1].isLetter())) {
                pos++; return computeE(mc.precision)
            }
            val start = pos
            while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
            if (start == pos) throw IllegalArgumentException("Format error")
            return BigDecimal(s.substring(start, pos), mc)
        }

        private fun parsePostfixArgForFunction(): BigDecimal {
            return if (peek() == '(') parsePrimary() else parseUnary()
        }

        /** For |angle| >= 1 a result this close to 0 is rounding noise (e.g. sin(π)), so it is exactly 0. */
        private fun snapZero(r: BigDecimal, rad: BigDecimal): BigDecimal {
            if (r.signum() == 0) return r
            val limit = BigDecimal.ONE.movePointLeft(mc.precision - 3)
            return if (rad.abs() >= BigDecimal.ONE && r.abs() < limit) BigDecimal.ZERO else r
        }

        private fun applyBigFunc(name: String, x: BigDecimal): BigDecimal {
            val pi = computePi(mc.precision)
            val degToRad = pi.divide(BigDecimal(180), mc)
            val rad = if (degrees && name in setOf("sin", "cos", "tan")) x.remainder(BigDecimal(360)).multiply(degToRad, mc) else x
            return when (name) {
                "sin" -> snapZero(bigSin(rad, mc), rad)
                "cos" -> snapZero(bigCos(rad, mc), rad)
                "tan" -> {
                    val c = snapZero(bigCos(rad, mc), rad)
                    if (c.signum() == 0) throw ArithmeticException("Can't calculate")
                    snapZero(bigSin(rad, mc), rad).divide(c, mc)
                }
                "asin" -> {
                    val oneMinusX2 = BigDecimal.ONE.subtract(x.multiply(x, mc), mc)
                    val r = if (oneMinusX2.compareTo(BigDecimal.ZERO) == 0) {
                        pi.divide(BigDecimal(2), mc).multiply(BigDecimal(x.signum()))
                    } else {
                        bigAtan(x.divide(bigSqrt(oneMinusX2, mc), mc), mc)
                    }
                    if (degrees) r.divide(degToRad, mc) else r
                }
                "acos" -> {
                    val oneMinusX2 = BigDecimal.ONE.subtract(x.multiply(x, mc), mc)
                    val asinVal = if (oneMinusX2.compareTo(BigDecimal.ZERO) == 0) {
                        pi.divide(BigDecimal(2), mc).multiply(BigDecimal(x.signum()))
                    } else {
                        bigAtan(x.divide(bigSqrt(oneMinusX2, mc), mc), mc)
                    }
                    val r = pi.divide(BigDecimal(2), mc).subtract(asinVal, mc)
                    if (degrees) r.divide(degToRad, mc) else r
                }
                "atan" -> {
                    val r = bigAtan(x, mc)
                    if (degrees) r.divide(degToRad, mc) else r
                }
                "ln" -> bigLn(x, mc)
                "log" -> bigLn(x, mc).divide(bigLn(BigDecimal.TEN, mc), mc)
                "sqrt" -> bigSqrt(x, mc)
                else -> throw IllegalArgumentException("Format error")
            }
        }
    }

    private class PQT(val p: BigInteger, val q: BigInteger, val t: BigInteger)

    private val C3_OVER_24 = BigInteger("10939058860032000")

    /** Chudnovsky series, binary splitting: fast enough for tens of thousands of digits. */
    private fun piSplit(a: Int, b: Int): PQT {
        checkCancel()
        if (b - a == 1) {
            if (a == 0) return PQT(BigInteger.ONE, BigInteger.ONE, BigInteger.valueOf(13591409L))
            val al = a.toLong()
            val p = BigInteger.valueOf(6 * al - 5).multiply(BigInteger.valueOf(2 * al - 1)).multiply(BigInteger.valueOf(6 * al - 1))
            val q = BigInteger.valueOf(al).pow(3).multiply(C3_OVER_24)
            var t = p.multiply(BigInteger.valueOf(13591409L + 545140134L * al))
            if (a % 2 == 1) t = t.negate()
            return PQT(p, q, t)
        }
        val m = (a + b) ushr 1
        val l = piSplit(a, m)
        val r = piSplit(m, b)
        return PQT(l.p.multiply(r.p), l.q.multiply(r.q), r.q.multiply(l.t).add(l.p.multiply(r.t)))
    }

    private fun computePi(digits: Int): BigDecimal {
        synchronized(cacheLock) {
            if (digits <= cachedPiPrecision) return cachedPi.round(MathContext(digits, RoundingMode.HALF_UP))
        }
        val d = digits + 12
        val terms = (d / 14.181647462725477).toInt() + 2
        val r = piSplit(0, terms)
        checkCancel()
        val root = isqrt(BigInteger.valueOf(10005).multiply(BigInteger.TEN.pow(2 * d)))
        checkCancel()
        val scaled = r.q.multiply(BigInteger.valueOf(426880)).multiply(root).divide(r.t)
        val pi = BigDecimal(scaled, d)
        synchronized(cacheLock) {
            if (digits > cachedPiPrecision) {
                cachedPi = pi
                cachedPiPrecision = digits
            }
        }
        return pi.round(MathContext(digits, RoundingMode.HALF_UP))
    }

    private class TQ(val t: BigInteger, val q: BigInteger)

    /** t/q = sum_{j=a+1..b} 1 / ((a+1)(a+2)...j) */
    private fun eSplit(a: Int, b: Int): TQ {
        checkCancel()
        if (b - a == 1) return TQ(BigInteger.ONE, BigInteger.valueOf(b.toLong()))
        val m = (a + b) ushr 1
        val l = eSplit(a, m)
        val r = eSplit(m, b)
        return TQ(l.t.multiply(r.q).add(r.t), l.q.multiply(r.q))
    }

    private fun computeE(digits: Int): BigDecimal {
        synchronized(cacheLock) {
            if (digits <= cachedEPrecision) return cachedE.round(MathContext(digits, RoundingMode.HALF_UP))
        }
        val d = digits + 12
        var n = 1
        var lg = 0.0
        while (lg < d + 2) { n++; lg += log10(n.toDouble()) }
        val r = eSplit(0, n)
        checkCancel()
        val scaled = r.t.add(r.q).multiply(BigInteger.TEN.pow(d)).divide(r.q)
        val e = BigDecimal(scaled, d)
        synchronized(cacheLock) {
            if (digits > cachedEPrecision) {
                cachedE = e
                cachedEPrecision = digits
            }
        }
        return e.round(MathContext(digits, RoundingMode.HALF_UP))
    }

    /** floor(sqrt(n)) by recursive Newton: one full-size division per level, sizes halve each level. */
    private fun isqrt(n: BigInteger): BigInteger {
        if (n.signum() <= 0) return BigInteger.ZERO
        val bits = n.bitLength()
        if (bits <= 52) {
            val v = n.toLong()
            var r = Math.sqrt(v.toDouble()).toLong()
            while (r * r > v) r--
            while ((r + 1) * (r + 1) <= v) r++
            return BigInteger.valueOf(r)
        }
        checkCancel()
        val s = bits / 4
        val hi = isqrt(n.shiftRight(2 * s))
        var x = hi.shiftLeft(s)
        x = x.add(n.divide(x)).shiftRight(1)
        while (true) {
            val y = x.add(n.divide(x)).shiftRight(1)
            if (y >= x) break
            x = y
        }
        return x
    }

    private fun bigSqrt(x: BigDecimal, mc: MathContext): BigDecimal {
        if (x.signum() == 0) return BigDecimal.ZERO
        if (x.signum() < 0) throw ArithmeticException("Can't calculate")
        val prec = mc.precision + 4
        val intDigits = x.precision() - x.scale()
        val t = (prec - intDigits / 2).coerceAtLeast(0)
        val n = x.movePointRight(2 * t).toBigInteger()
        return BigDecimal(isqrt(n), t).round(mc)
    }

    private fun bigExp(x: BigDecimal, mc: MathContext): BigDecimal {
        if (x.compareTo(BigDecimal.ZERO) == 0) return BigDecimal.ONE
        val workMc = MathContext(mc.precision + 6, RoundingMode.HALF_UP)
        val r = x.divide(BigDecimal.valueOf(256), workMc)
        var sum = BigDecimal.ONE
        var term = BigDecimal.ONE
        val tol = BigDecimal.ONE.movePointLeft(workMc.precision)
        var n = 1
        val maxN = workMc.precision + 1000
        while (n < maxN) {
            checkCancel()
            term = term.multiply(r, workMc).divide(BigDecimal.valueOf(n.toLong()), workMc)
            if (term.abs() < tol) break
            sum = sum.add(term, workMc)
            n++
        }
        repeat(8) { sum = sum.multiply(sum, workMc) }
        return sum.round(mc)
    }

    private fun bigLn(x: BigDecimal, mc: MathContext): BigDecimal {
        if (x.signum() <= 0) throw ArithmeticException("Can't calculate")
        val workMc = MathContext(mc.precision + 6, RoundingMode.HALF_UP)
        val k = BigDecimal.valueOf(ln(x.toDouble()))
        val u = x.multiply(bigExp(k.negate(), workMc), workMc).subtract(BigDecimal.ONE, workMc)
        var sum = BigDecimal.ZERO
        var uPow = u
        val tol = BigDecimal.ONE.movePointLeft(workMc.precision)
        var n = 1
        val maxN = workMc.precision + 1000
        while (n < maxN) {
            checkCancel()
            val step = uPow.divide(BigDecimal.valueOf(n.toLong()), workMc)
            if (step.abs() < tol) break
            sum = if (n % 2 == 1) sum.add(step, workMc) else sum.subtract(step, workMc)
            uPow = uPow.multiply(u, workMc)
            n++
        }
        return k.add(sum, workMc).round(mc)
    }

    private fun bigSin(rad: BigDecimal, mc: MathContext): BigDecimal {
        val workMc = MathContext(mc.precision + 6, RoundingMode.HALF_UP)
        val twoPi = computePi(workMc.precision).multiply(BigDecimal.valueOf(2), workMc)
        val x = rad.remainder(twoPi, workMc)
        val x2 = x.multiply(x, workMc)
        var term = x
        var sum = x
        val tol = BigDecimal.ONE.movePointLeft(workMc.precision)
        var n = 1
        val maxN = workMc.precision + 1000
        while (n < maxN) {
            checkCancel()
            val denom = BigDecimal.valueOf((2L * n) * (2L * n + 1))
            term = term.multiply(x2, workMc).divide(denom, workMc).negate()
            if (term.abs() < tol) break
            sum = sum.add(term, workMc)
            n++
        }
        return sum.round(mc)
    }

    private fun bigCos(rad: BigDecimal, mc: MathContext): BigDecimal {
        val workMc = MathContext(mc.precision + 6, RoundingMode.HALF_UP)
        val twoPi = computePi(workMc.precision).multiply(BigDecimal.valueOf(2), workMc)
        val x = rad.remainder(twoPi, workMc)
        val x2 = x.multiply(x, workMc)
        var term = BigDecimal.ONE
        var sum = BigDecimal.ONE
        val tol = BigDecimal.ONE.movePointLeft(workMc.precision)
        var n = 1
        val maxN = workMc.precision + 1000
        while (n < maxN) {
            checkCancel()
            val denom = BigDecimal.valueOf((2L * n - 1) * (2L * n))
            term = term.multiply(x2, workMc).divide(denom, workMc).negate()
            if (term.abs() < tol) break
            sum = sum.add(term, workMc)
            n++
        }
        return sum.round(mc)
    }

    private fun bigAtan(x: BigDecimal, mc: MathContext): BigDecimal {
        val workMc = MathContext(mc.precision + 6, RoundingMode.HALF_UP)
        val a0 = BigDecimal.valueOf(atan(x.toDouble()))
        val sinA = bigSin(a0, workMc)
        val cosA = bigCos(a0, workMc)
        val tanA = sinA.divide(cosA, workMc)
        val u = x.subtract(tanA, workMc).divide(BigDecimal.ONE.add(x.multiply(tanA, workMc), workMc), workMc)
        val u2 = u.multiply(u, workMc)
        var term = u
        var sum = u
        val tol = BigDecimal.ONE.movePointLeft(workMc.precision)
        var n = 1
        val maxN = workMc.precision + 1000
        while (n < maxN) {
            checkCancel()
            term = term.multiply(u2, workMc).negate()
            val step = term.divide(BigDecimal.valueOf((2L * n + 1)), workMc)
            if (step.abs() < tol) break
            sum = sum.add(step, workMc)
            n++
        }
        return a0.add(sum, workMc).round(mc)
    }
}
