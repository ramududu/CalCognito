package com.onion.calcognito

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Runs vault transfers (adding, unhiding, encrypting and decrypting files) one after another on a background thread.
 *
 * The work belongs to the process, not to the activity: it keeps going when the progress card is hidden, when
 * the vault locks, and when the app is closed. [TransferService] (a foreground service) keeps the process alive
 * while anything is queued or running, and a partial wake lock keeps the CPU awake while the screen is off.
 *
 * Threading: [enqueue], [setListener], [consume], [cancel] and [cancelAll] are called on the main thread, the
 * job's work runs on the transfer thread, and listener callbacks always arrive on the main thread.
 */
object TransferManager {

    enum class Kind { ADD, UNHIDE, ENCRYPT, DECRYPT }
    enum class State { QUEUED, RUNNING, DONE }

    /** The screen showing progress. Attached while the app is in front; jobs carry on without it. */
    interface Listener {
        /** Progress, label or state changed (also replayed when a listener attaches). */
        fun onJobUpdate(job: Job)

        /** The job ended; its [Job.result] is ready. Replayed on attach until the job is [consume]d. */
        fun onJobFinished(job: Job)
    }

    /**
     * One unit of work. [work] runs on the transfer thread and returns a result object for whoever handles the
     * outcome. It must not hold on to an Activity. It should poll [cancelled] and report bytes through [addBytes].
     */
    class Job(
        val kind: Kind,
        val title: String,
        val count: Int,
        val totalBytes: Long,
        /** Content URIs the work reads. They are granted to the service so access survives the app closing. */
        val grantUris: List<Uri>,
        /** How long to wait before the progress card appears; negative means the job never shows a card. */
        val cardDelayMs: Long,
        internal val work: (Context, Job) -> Any?
    ) {
        @Volatile var state = State.QUEUED
        @Volatile var cancelled = false
        @Volatile var progress = if (totalBytes > 0L) 0f else -1f
        @Volatile var failed = false
        @Volatile var result: Any? = null

        /** Set when the person taps Hide: the job keeps running but its card stays away. */
        @Volatile var userHidden = false

        /** The result is not wanted (the vault was wiped): drop the job as soon as it stops. */
        @Volatile var discard = false

        /** What is being worked on right now, e.g. a file name or "2 of 5". */
        @Volatile var label: String = ""
            set(value) {
                field = value
                TransferManager.publish(this)
            }

        val createdAt: Long = SystemClock.uptimeMillis()

        private val doneBytes = AtomicLong(0)
        private var lastPublish = 0L

        /** Called from the work after each block with the number of bytes just handled. */
        fun addBytes(delta: Long) {
            val d = doneBytes.addAndGet(delta)
            if (totalBytes <= 0L) return
            val now = SystemClock.uptimeMillis()
            if (now - lastPublish < 100L) return
            lastPublish = now
            progress = (d.toFloat() / totalBytes).coerceIn(0f, 0.99f)
            TransferManager.publish(this)
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor { r -> Thread(r, "vault-transfer") }

    // Main thread only.
    private val jobs = ArrayList<Job>()
    private var listener: Listener? = null

    private val active = AtomicInteger(0)

    /** True while any job is queued or running. */
    fun isBusy(): Boolean = active.get() > 0

    /** Queues [job]; it starts as soon as the ones before it are done. */
    fun enqueue(context: Context, job: Job) {
        val app = context.applicationContext
        jobs.add(job)
        active.incrementAndGet()
        launchService(app, job)
        executor.execute { runJob(app, job) }
        publish(job)
    }

    fun setListener(l: Listener?) {
        listener = l
        if (l == null) return
        for (job in jobs.toList()) {
            if (job.state == State.DONE) l.onJobFinished(job) else l.onJobUpdate(job)
        }
    }

    fun clearListener(l: Listener) {
        if (listener === l) listener = null
    }

    /** The unfinished job that should have the progress card: the oldest one the person hasn't hidden. */
    fun cardJob(): Job? = jobs.firstOrNull { it.state != State.DONE && !it.userHidden && it.cardDelayMs >= 0L }

    /** The result has been handled; forget the job. */
    fun consume(job: Job) {
        jobs.remove(job)
    }

    fun cancel(job: Job) {
        if (job.state == State.DONE) return
        job.cancelled = true
        publish(job)
    }

    fun cancelAll() {
        for (job in jobs.toList()) cancel(job)
    }

    /** Cancels everything and forgets all results, for when the vault is wiped. */
    fun cancelAndForgetAll() {
        for (job in jobs.toList()) {
            if (job.state == State.DONE) {
                jobs.remove(job)
            } else {
                job.discard = true
                cancel(job)
            }
        }
    }

    /** Progress of the job being worked on for the notification: -1 when unknown. */
    fun currentPercent(): Int {
        val job = jobs.firstOrNull { it.state == State.RUNNING } ?: return -1
        if (job.cancelled || job.progress < 0f) return -1
        return (job.progress * 100).toInt().coerceIn(0, 100)
    }

    internal fun publish(job: Job) {
        main.post {
            if (job.state == State.DONE) return@post
            listener?.onJobUpdate(job)
            TransferService.refresh()
        }
    }

    private fun runJob(app: Context, job: Job) {
        var out: Any? = null
        if (!job.cancelled) {
            job.state = State.RUNNING
            publish(job)
            val lock = acquireWakeLock(app)
            try {
                out = job.work(app, job)
            } catch (e: Throwable) {
                job.failed = true
            } finally {
                try { if (lock?.isHeld == true) lock.release() } catch (_: Exception) {}
            }
        }
        job.result = out
        main.post { finish(app, job) }
    }

    private fun finish(app: Context, job: Job) {
        job.state = State.DONE
        val left = active.decrementAndGet()
        if (job.discard) {
            jobs.remove(job)
        } else {
            val l = listener
            if (l != null) {
                l.onJobFinished(job)
            } else if (!job.cancelled) {
                // Nobody is looking (the app was closed): leave a quiet note that it finished.
                TransferService.notifyDone(app)
            }
        }
        if (left <= 0) TransferService.stopWhenIdle()
    }

    private fun acquireWakeLock(app: Context): PowerManager.WakeLock? = try {
        val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
        pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "calculator:transfer").apply {
            setReferenceCounted(false)
            acquire(6L * 60 * 60 * 1000)
        }
    } catch (_: Exception) {
        null
    }

    /**
     * Starts the foreground service that keeps the process alive. The picked files' URIs travel with the intent,
     * which gives the service its own access grant: without it, Android could revoke the picker's temporary access
     * as soon as the activity is gone, in the middle of a copy.
     */
    private fun launchService(app: Context, job: Job) {
        val intent = Intent(app, TransferService::class.java)
        val uris = job.grantUris
        if (uris.isNotEmpty()) {
            val clip = ClipData.newRawUri("files", uris[0])
            for (i in 1 until uris.size) clip.addItem(ClipData.Item(uris[i]))
            intent.clipData = clip
            intent.flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            try {
                ContextCompat.startForegroundService(app, intent)
                return
            } catch (_: SecurityException) {
                // Some files can't be written to (so their original can't be deleted by us); pass on reading only.
                intent.flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
            } catch (_: Exception) {
                return
            }
        }
        try {
            ContextCompat.startForegroundService(app, intent)
        } catch (_: Exception) {
            // The work still runs in this process; it just isn't protected from being closed.
        }
    }
}
