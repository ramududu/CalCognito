package com.onion.calcognito

import android.app.Activity
import android.app.Dialog
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.TextUtils
import android.text.format.DateFormat
import android.text.format.Formatter
import android.util.LruCache
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.util.Date
import java.util.concurrent.Executors

/** The colours the picker uses (taken from the app's current theme by the caller). */
class PickerColors(
    val bg: Int, val text: Int, val sub: Int,
    val chipBg: Int, val chipFg: Int, val chipOnBg: Int, val chipOnFg: Int,
    val fabBg: Int, val fabFg: Int,
    val tint: Int, val checkBg: Int, val checkFg: Int,
    val folder: Int, val divider: Int, val ripple: Int
)

/**
 * Full-screen file browser for adding files to the vault.
 *
 * Browse folders, tap files to tick them (the ticks stay while you move between folders), then press the round
 * tick button at the bottom right to add everything. Needs the app to be able to read storage directly (All files
 * access on Android 11+), which the caller checks before showing it.
 */
class FilePicker(
    private val activity: Activity,
    private val c: PickerColors,
    private val lightBars: Boolean,
    private val onPicked: (List<File>) -> Unit,
    private val onSystemPicker: () -> Unit
) {
    private class Entry(val file: File, val isDir: Boolean, val name: String, val size: Long, val modified: Long)

    private val ui = Handler(Looper.getMainLooper())
    private val lister = Executors.newSingleThreadExecutor()
    private val thumbs = Executors.newFixedThreadPool(2)
    private val cache = LruCache<String, Bitmap>(120)
    private val selected = LinkedHashSet<String>()
    private val scrollMemory = HashMap<String, Int>()
    private val roots: List<Pair<String, File>> = storageRoots()
    private val quick: List<Pair<String, File>> = quickFolders()
    private var rootDir: File = roots[0].second
    private var currentDir: File = rootDir
    private var entries: List<Entry> = emptyList()
    private var sort = 0
    private var loadGen = 0
    private var loading = false
    private var loadError = false
    private var closed = false
    private var lastBackAt = 0L
    private var restoreScrollOnLoad = false

    private lateinit var dialog: Dialog
    private lateinit var titleView: TextView
    private lateinit var subtitleView: TextView
    private lateinit var chipRow: LinearLayout
    private lateinit var list: RecyclerView
    private lateinit var emptyView: TextView
    private lateinit var fab: FrameLayout
    private lateinit var rowAdapter: RowAdapter

    private fun dp(v: Int) = (v * activity.resources.displayMetrics.density).toInt()
    private fun dpf(v: Int) = v * activity.resources.displayMetrics.density

    // ---------------------------------------------------------------------------------------------
    // Setup
    // ---------------------------------------------------------------------------------------------

    @Suppress("DEPRECATION")
    private fun storageRoots(): List<Pair<String, File>> {
        val primary = Environment.getExternalStorageDirectory()
        val out = ArrayList<Pair<String, File>>()
        out.add("Internal storage" to primary)
        try {
            for (dir in activity.getExternalFilesDirs(null)) {
                if (dir == null) continue
                val p = dir.absolutePath
                val i = p.indexOf("/Android/data")
                if (i <= 0) continue
                val root = File(p.substring(0, i))
                if (out.any { it.second.absolutePath == root.absolutePath }) continue
                if (root.canRead()) out.add((if (out.size == 1) "SD card" else "SD card ${out.size}") to root)
            }
        } catch (_: Exception) {
        }
        return out
    }

    @Suppress("DEPRECATION")
    private fun quickFolders(): List<Pair<String, File>> {
        val primary = Environment.getExternalStorageDirectory()
        return listOf("Download", "DCIM", "Pictures", "Movies", "Music", "Documents")
            .map { it to File(primary, it) }
            .filter { it.second.isDirectory }
    }

    @Suppress("DEPRECATION")
    fun show(): Dialog {
        val d = object : Dialog(activity, android.R.style.Theme_Black_NoTitleBar) {
            @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
            override fun onBackPressed() {
                handleBack()
            }

            override fun dismiss() {
                shutdown()
                super.dismiss()
            }
        }
        dialog = d
        d.window?.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        d.setContentView(buildUi())
        d.window?.let { w ->
            w.setBackgroundDrawable(ColorDrawable(c.bg))
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            WindowCompat.setDecorFitsSystemWindows(w, false)
            w.statusBarColor = Color.TRANSPARENT
            w.navigationBarColor = Color.TRANSPARENT
            val ctl = WindowCompat.getInsetsController(w, w.decorView)
            ctl.isAppearanceLightStatusBars = lightBars
            ctl.isAppearanceLightNavigationBars = lightBars
        }
        open(rootDir)
        d.show()
        return d
    }

    private fun shutdown() {
        if (closed) return
        closed = true
        ui.removeCallbacksAndMessages(null)
        lister.shutdownNow()
        thumbs.shutdownNow()
        cache.evictAll()
    }

    // ---------------------------------------------------------------------------------------------
    // UI
    // ---------------------------------------------------------------------------------------------

    private fun iconBtn(res: Int, desc: String, onClick: () -> Unit): ImageView = ImageView(activity).apply {
        setImageResource(res)
        setColorFilter(c.sub)
        scaleType = ImageView.ScaleType.CENTER_INSIDE
        setPadding(dp(12), dp(12), dp(12), dp(12))
        contentDescription = desc
        background = RippleDrawable(
            ColorStateList.valueOf(c.ripple), null,
            GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.BLACK) }
        )
        setOnClickListener { onClick() }
    }

    private fun buildUi(): View {
        val root = FrameLayout(activity).apply { setBackgroundColor(c.bg) }
        val column = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }

        // Top bar: back, title + path, select-all-in-this-folder.
        titleView = TextView(activity).apply {
            setTextColor(c.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        subtitleView = TextView(activity).apply {
            setTextColor(c.sub)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.START
        }
        val titleCol = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            addView(titleView, LinearLayout.LayoutParams(-1, -2))
            addView(subtitleView, LinearLayout.LayoutParams(-1, -2))
        }
        val bar = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(8), dp(8), dp(4))
            addView(iconBtn(R.drawable.ic_arrow_back, "Back") { handleBack() }, LinearLayout.LayoutParams(dp(48), dp(48)))
            addView(titleCol, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(4); rightMargin = dp(4) })
            addView(
                iconBtn(R.drawable.ic_select_all, "Select all files in this folder") { toggleAllHere() },
                LinearLayout.LayoutParams(dp(48), dp(48))
            )
        }
        column.addView(bar, LinearLayout.LayoutParams(-1, -2))

        // Chips: Clear, storage, quick folders, sort, system picker.
        chipRow = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(16), dp(4), dp(8), dp(8))
        }
        column.addView(HorizontalScrollView(activity).apply {
            isHorizontalScrollBarEnabled = false
            addView(chipRow)
        }, LinearLayout.LayoutParams(-1, -2))
        column.addView(View(activity).apply { setBackgroundColor(c.divider) }, LinearLayout.LayoutParams(-1, dp(1)))

        // File list.
        rowAdapter = RowAdapter()
        list = RecyclerView(activity).apply {
            layoutManager = LinearLayoutManager(activity)
            adapter = rowAdapter
            itemAnimator = null
            clipToPadding = false
            setPadding(0, 0, 0, dp(120))
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        emptyView = TextView(activity).apply {
            setTextColor(c.sub)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        column.addView(FrameLayout(activity).apply {
            addView(list, FrameLayout.LayoutParams(-1, -1))
            addView(emptyView, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        }, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(column, FrameLayout.LayoutParams(-1, -1))

        // The tick button, bottom right: adds everything that is ticked.
        val fabShape = GradientDrawable().apply { cornerRadius = dpf(28); setColor(c.fabBg) }
        val fabMask = GradientDrawable().apply { cornerRadius = dpf(28); setColor(Color.BLACK) }
        fab = FrameLayout(activity).apply {
            background = RippleDrawable(ColorStateList.valueOf(c.ripple), fabShape, fabMask)
            elevation = dpf(6)
            isClickable = true
            isFocusable = true
            contentDescription = "Add selected files"
            visibility = View.GONE
            setOnClickListener { finish() }
            addView(ImageView(activity).apply {
                setImageResource(R.drawable.ic_check)
                setColorFilter(c.fabFg)
            }, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.CENTER))
        }
        root.addView(fab, FrameLayout.LayoutParams(dp(80), dp(80), Gravity.BOTTOM or Gravity.END).apply {
            setMargins(0, 0, dp(16), dp(32))
        })

        // Edge-to-edge: keep the bar below the status bar and the tick button above the navigation bar.
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, ins ->
            val b = ins.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(b.left, b.top, b.right, 0)
            (fab.layoutParams as FrameLayout.LayoutParams).bottomMargin = dp(32) + b.bottom
            fab.requestLayout()
            list.setPadding(0, 0, 0, dp(120) + b.bottom)
            ins
        }
        return root
    }

    private fun chip(label: String, on: Boolean, onClick: () -> Unit): TextView = TextView(activity).apply {
        text = label
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        setTextColor(if (on) c.chipOnFg else c.chipFg)
        typeface = if (on) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        setPadding(dp(14), dp(7), dp(14), dp(7))
        background = GradientDrawable().apply {
            cornerRadius = dpf(100)
            setColor(if (on) c.chipOnBg else c.chipBg)
        }
        setOnClickListener { onClick() }
    }

    private fun renderChips() {
        chipRow.removeAllViews()
        fun add(v: View) = chipRow.addView(v, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
        if (selected.isNotEmpty()) {
            add(chip("Clear (${selected.size})", false) {
                selected.clear()
                refreshSelection()
            })
        }
        for ((label, dir) in roots) add(chip(label, currentDir == dir, { rootDir = dir; open(dir) }))
        for ((label, dir) in quick) add(chip(label, currentDir == dir, { rootDir = roots[0].second; open(dir) }))
        val sortLabels = listOf("A–Z", "Newest", "Largest")
        add(chip("Sort: ${sortLabels[sort]}", false) {
            sort = (sort + 1) % 3
            entries = sorted(entries)
            rowAdapter.notifyDataSetChanged()
            renderChips()
        })
        add(chip("System picker", false) {
            dialog.dismiss()
            onSystemPicker()
        })
    }

    private fun rootLabel(): String = roots.firstOrNull { it.second == rootDir }?.first ?: "Storage"

    private fun updateHeader() {
        val n = selected.size
        titleView.text = when {
            n > 0 -> "$n selected"
            currentDir == rootDir -> rootLabel()
            else -> currentDir.name
        }
        val rel = currentDir.path.removePrefix(rootDir.path).trim('/')
        subtitleView.text = if (rel.isEmpty()) rootLabel() else rootLabel() + " › " + rel.replace("/", " › ")
    }

    private fun updateEmpty() {
        val show = !loading && entries.isEmpty()
        emptyView.visibility = if (show) View.VISIBLE else View.GONE
        emptyView.text = if (loadError) "Can't open this folder" else "This folder is empty"
    }

    private fun updateFab() {
        val show = selected.isNotEmpty()
        fab.animate().cancel()
        if (show) {
            if (fab.visibility != View.VISIBLE) {
                fab.scaleX = 0.6f
                fab.scaleY = 0.6f
                fab.alpha = 0f
                fab.visibility = View.VISIBLE
            }
            fab.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(180).start()
        } else if (fab.visibility == View.VISIBLE) {
            fab.animate().scaleX(0.6f).scaleY(0.6f).alpha(0f).setDuration(140)
                .withEndAction { if (selected.isEmpty()) fab.visibility = View.GONE }.start()
        }
    }

    // ---------------------------------------------------------------------------------------------
    // Navigation and loading
    // ---------------------------------------------------------------------------------------------

    private fun open(dir: File, restore: Boolean = false) {
        if (::list.isInitialized) {
            val lm = list.layoutManager as LinearLayoutManager
            scrollMemory[currentDir.path] = lm.findFirstVisibleItemPosition().coerceAtLeast(0)
        }
        currentDir = dir
        restoreScrollOnLoad = restore
        updateHeader()
        renderChips()
        loadCurrent()
    }

    private fun loadCurrent() {
        val gen = ++loadGen
        val dir = currentDir
        loading = true
        updateEmpty()
        try {
            lister.execute {
                val raw = try { dir.listFiles() } catch (_: SecurityException) { null }
                val items = raw?.filter { !it.name.startsWith(".") }?.map {
                    val isDir = it.isDirectory
                    Entry(it, isDir, it.name, if (isDir) 0L else it.length(), it.lastModified())
                }
                ui.post {
                    if (closed || gen != loadGen) return@post
                    loading = false
                    loadError = items == null
                    entries = sorted(items ?: emptyList())
                    rowAdapter.notifyDataSetChanged()
                    updateEmpty()
                    val lm = list.layoutManager as LinearLayoutManager
                    if (restoreScrollOnLoad) lm.scrollToPositionWithOffset(scrollMemory[dir.path] ?: 0, 0)
                    else lm.scrollToPositionWithOffset(0, 0)
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun sorted(items: List<Entry>): List<Entry> {
        val inner: Comparator<Entry> = when (sort) {
            1 -> compareByDescending<Entry> { it.modified }
            2 -> compareByDescending<Entry> { it.size }
            else -> compareBy<Entry, String>(String.CASE_INSENSITIVE_ORDER) { it.name }
        }
        return items.sortedWith(compareByDescending<Entry> { it.isDir }.then(inner))
    }

    private fun handleBack() {
        if (currentDir != rootDir) {
            val parent = currentDir.parentFile
            if (parent != null) {
                open(parent, restore = true)
                return
            }
        }
        if (selected.isNotEmpty()) {
            val now = SystemClock.uptimeMillis()
            if (now - lastBackAt > 2000L) {
                lastBackAt = now
                Toast.makeText(activity, "Press back again to discard ${selected.size} selected", Toast.LENGTH_SHORT).show()
                return
            }
        }
        dialog.dismiss()
    }

    // ---------------------------------------------------------------------------------------------
    // Selection
    // ---------------------------------------------------------------------------------------------

    private fun refreshSelection() {
        updateHeader()
        renderChips()
        rowAdapter.notifyDataSetChanged()
        updateFab()
    }

    private fun toggle(path: String, position: Int) {
        if (!selected.add(path)) selected.remove(path)
        if (position != RecyclerView.NO_POSITION) rowAdapter.notifyItemChanged(position)
        updateHeader()
        renderChips()
        updateFab()
    }

    /** Ticks every file in the open folder, or unticks them if they are all ticked already. */
    private fun toggleAllHere() {
        val files = entries.filter { !it.isDir }
        if (files.isEmpty()) return
        if (files.all { it.file.path in selected }) files.forEach { selected.remove(it.file.path) }
        else files.forEach { selected.add(it.file.path) }
        refreshSelection()
    }

    private fun finish() {
        val files = selected.map { File(it) }.filter { it.isFile }
        if (files.isEmpty()) {
            Toast.makeText(activity, "Those files are no longer there", Toast.LENGTH_SHORT).show()
            return
        }
        dialog.dismiss()
        onPicked(files)
    }

    // ---------------------------------------------------------------------------------------------
    // Rows
    // ---------------------------------------------------------------------------------------------

    private inner class RowHolder(
        val row: LinearLayout, val thumb: ImageView, val name: TextView, val meta: TextView,
        val check: FrameLayout, val checkIcon: ImageView
    ) : RecyclerView.ViewHolder(row)

    private inner class RowAdapter : RecyclerView.Adapter<RowHolder>() {
        override fun getItemCount() = entries.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowHolder {
            val thumb = ImageView(activity).apply {
                background = GradientDrawable().apply { cornerRadius = dpf(8); setColor(c.chipBg) }
                clipToOutline = true
            }
            val name = TextView(activity).apply {
                setTextColor(c.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            val meta = TextView(activity).apply {
                setTextColor(c.sub)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                maxLines = 1
            }
            val checkIcon = ImageView(activity).apply {
                setImageResource(R.drawable.ic_check)
                setColorFilter(c.checkFg)
            }
            val check = FrameLayout(activity).apply {
                addView(checkIcon, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
            }
            val col = LinearLayout(activity).apply {
                orientation = LinearLayout.VERTICAL
                addView(name, LinearLayout.LayoutParams(-1, -2))
                addView(meta, LinearLayout.LayoutParams(-1, -2))
            }
            val row = LinearLayout(activity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(16), dp(8), dp(16), dp(8))
                layoutParams = RecyclerView.LayoutParams(-1, -2)
                isClickable = true
                foreground = RippleDrawable(ColorStateList.valueOf(c.ripple), null, ColorDrawable(Color.BLACK))
                addView(thumb, LinearLayout.LayoutParams(dp(48), dp(48)).apply { rightMargin = dp(16) })
                addView(col, LinearLayout.LayoutParams(0, -2, 1f))
                addView(check, LinearLayout.LayoutParams(dp(26), dp(26)).apply { leftMargin = dp(12) })
            }
            return RowHolder(row, thumb, name, meta, check, checkIcon)
        }

        override fun onBindViewHolder(h: RowHolder, position: Int) {
            val e = entries[position]
            h.name.text = e.name
            if (e.isDir) {
                h.thumb.tag = e.file.path
                setIcon(h.thumb, R.drawable.ic_folder, c.folder)
                h.meta.text = DateFormat.getMediumDateFormat(activity).format(Date(e.modified))
                h.check.visibility = View.GONE
                h.row.setBackgroundColor(Color.TRANSPARENT)
                h.row.setOnClickListener { open(e.file) }
                return
            }
            h.meta.text = Formatter.formatShortFileSize(activity, e.size) + " · " +
                DateFormat.getMediumDateFormat(activity).format(Date(e.modified))
            h.check.visibility = View.VISIBLE
            val on = e.file.path in selected
            h.row.setBackgroundColor(if (on) c.tint else Color.TRANSPARENT)
            h.check.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                if (on) setColor(c.checkBg) else { setColor(Color.TRANSPARENT); setStroke(dp(2), c.sub) }
            }
            h.checkIcon.visibility = if (on) View.VISIBLE else View.INVISIBLE
            h.row.setOnClickListener { toggle(e.file.path, h.bindingAdapterPosition) }
            bindThumb(h.thumb, e)
        }
    }

    private fun setIcon(iv: ImageView, res: Int, tint: Int) {
        iv.setImageResource(res)
        iv.setColorFilter(tint)
        iv.scaleType = ImageView.ScaleType.CENTER_INSIDE
        iv.setPadding(dp(10), dp(10), dp(10), dp(10))
    }

    private fun showThumb(iv: ImageView, bm: Bitmap) {
        iv.clearColorFilter()
        iv.setPadding(0, 0, 0, 0)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        iv.setImageBitmap(bm)
    }

    private fun bindThumb(iv: ImageView, e: Entry) {
        val path = e.file.path
        val mime = VaultManager.mimeFor(e.name)
        val isImage = mime.startsWith("image/")
        val isVideo = mime.startsWith("video/")
        iv.tag = path
        setIcon(
            iv,
            when {
                isImage -> R.drawable.ic_image
                isVideo || mime.startsWith("audio/") -> R.drawable.ic_play
                else -> R.drawable.ic_file
            },
            c.sub
        )
        if (!isImage && !isVideo) return
        val key = path + e.modified
        val hit = cache.get(key)
        if (hit != null) {
            showThumb(iv, hit)
            return
        }
        try {
            thumbs.execute {
                // The row may have been recycled for another file while this waited in the queue.
                if (iv.tag != path) return@execute
                val bm = loadThumb(e.file, isImage) ?: return@execute
                cache.put(key, bm)
                ui.post { if (!closed && iv.tag == path) showThumb(iv, bm) }
            }
        } catch (_: Exception) {
        }
    }

    private fun loadThumb(f: File, image: Boolean): Bitmap? {
        val target = 160
        return try {
            if (image) {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(f.path, bounds)
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
                var sample = 1
                while (bounds.outWidth / (sample * 2) >= target && bounds.outHeight / (sample * 2) >= target) sample *= 2
                val bm = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample })
                    ?: return null
                val degrees = try {
                    when (ExifInterface(f.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                        ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                        ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                        else -> 0f
                    }
                } catch (_: Exception) {
                    0f
                }
                if (degrees != 0f) {
                    Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, Matrix().apply { postRotate(degrees) }, true)
                } else {
                    bm
                }
            } else {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(f.path)
                    val frame = r.getFrameAtTime(-1L) ?: return null
                    val s = target.toFloat() / maxOf(frame.width, frame.height)
                    if (s >= 1f) frame
                    else Bitmap.createScaledBitmap(
                        frame, (frame.width * s).toInt().coerceAtLeast(1), (frame.height * s).toInt().coerceAtLeast(1), true
                    )
                } finally {
                    try { r.release() } catch (_: Exception) {}
                }
            }
        } catch (_: Throwable) {
            null
        }
    }
}
