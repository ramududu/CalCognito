package com.onion.calcognito

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInstaller
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Hidden apps.
 *
 * Android does not let one app run another app's code inside itself, and it never lets an app uninstall another
 * app silently. So "hiding" an app works like an archive:
 *
 *  1. [pack] copies the app's APK files (base + any split APKs) into ONE encrypted file, `<App name>.apks`,
 *     inside the vault's pre-created `Apps` folder.
 *  2. [requestUninstall] asks Android to uninstall the original. Android shows its own "Do you want to uninstall
 *     this app?" screen; the person has to confirm.
 *  3. Later, [install] re-installs the app straight from the vault (again with Android's confirmation screen).
 *     While it is installed it is visible on the home screen like any app; "Hide again" uninstalls it again.
 *
 * App DATA (logins, chats, game progress) lives in the app's private storage and cannot be copied by another app,
 * so it is NOT kept: a re-installed app starts fresh.
 */
object HiddenApps {
    const val EXT = ".apks"
    private const val PREF = "hidden_apps"
    private const val ICON_DIR = "hidden_app_icons"

    class Candidate(val pkg: String, val label: String, val icon: Drawable)

    // ---------------------------------------------------------------------------------------------
    // Listing
    // ---------------------------------------------------------------------------------------------

    /** Apps the person installed themselves and that have a launcher icon (system apps can't be uninstalled). */
    fun listCandidates(ctx: Context): List<Candidate> {
        val pm = ctx.packageManager
        val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val out = ArrayList<Candidate>()
        val seen = HashSet<String>()
        for (ri in pm.queryIntentActivities(launch, 0)) {
            val ai = ri.activityInfo?.applicationInfo ?: continue
            val pkg = ai.packageName
            if (pkg == ctx.packageName || !seen.add(pkg)) continue
            val system = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            if (system) continue
            out.add(Candidate(pkg, pm.getApplicationLabel(ai).toString(), pm.getApplicationIcon(ai)))
        }
        return out.sortedBy { it.label.lowercase() }
    }

    fun isInstalled(ctx: Context, pkg: String): Boolean = ctx.packageManager.getLaunchIntentForPackage(pkg) != null

    // ---------------------------------------------------------------------------------------------
    // Records (which vault file is which package) and icons
    // ---------------------------------------------------------------------------------------------

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    /** Cheap lookup (no file access) used when drawing the list. */
    fun packageOfFast(ctx: Context, vaultFile: File): String? = prefs(ctx).getString(VaultManager.displayName(vaultFile), null)

    /** Like [packageOfFast], but falls back to reading meta.json inside the file (e.g. after the file was renamed). */
    fun packageOf(ctx: Context, vaultFile: File): String? {
        packageOfFast(ctx, vaultFile)?.let { return it }
        return try {
            ZipInputStream(VaultManager.openStream(vaultFile).buffered(8192)).use { zin ->
                var pkg: String? = null
                while (pkg == null) {
                    val e = zin.nextEntry ?: break
                    if (e.name == "meta.json") pkg = JSONObject(String(zin.readBytes())).optString("package").ifEmpty { null }
                }
                pkg
            }?.also { prefs(ctx).edit().putString(VaultManager.displayName(vaultFile), it).apply() }
        } catch (_: Throwable) {
            null
        }
    }

    private fun iconFile(ctx: Context, displayName: String) =
        File(File(ctx.filesDir, ICON_DIR).apply { mkdirs() }, displayName.replace('/', '_') + ".png")

    fun iconFor(ctx: Context, vaultFile: File): Bitmap? = try {
        BitmapFactory.decodeFile(iconFile(ctx, VaultManager.displayName(vaultFile)).absolutePath)
    } catch (_: Throwable) {
        null
    }

    fun forget(ctx: Context, vaultFile: File) {
        val name = VaultManager.displayName(vaultFile)
        prefs(ctx).edit().remove(name).apply()
        iconFile(ctx, name).delete()
    }

    fun clearAll(ctx: Context) {
        prefs(ctx).edit().clear().apply()
        File(ctx.filesDir, ICON_DIR).deleteRecursively()
    }

    private fun toBitmap(d: Drawable, size: Int = 144): Bitmap {
        if (d is BitmapDrawable && d.bitmap != null && d.bitmap.width <= size * 2) return d.bitmap
        val bm = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bm)
        d.setBounds(0, 0, size, size)
        d.draw(c)
        return bm
    }

    // ---------------------------------------------------------------------------------------------
    // 1. Pack the app into the vault
    // ---------------------------------------------------------------------------------------------

    /**
     * Copies [pkg]'s APKs into an encrypted `.apks` file in the vault's Apps folder. Runs on the calling thread
     * (call it from a worker). Returns the vault file's display name, or null if anything failed (nothing is left behind).
     */
    fun pack(ctx: Context, pkg: String, onProgress: (Float) -> Unit): String? {
        val pm = ctx.packageManager
        val tmpDir = File(ctx.cacheDir, "vault_tmp").apply { mkdirs() }
        var zipFile: File? = null
        try {
            @Suppress("DEPRECATION")
            val info = pm.getPackageInfo(pkg, 0)
            val ai = info.applicationInfo ?: return null
            val label = pm.getApplicationLabel(ai).toString()
            val safeLabel = label.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), "_").trim().trimStart('.').ifEmpty { pkg }
            val apks = ArrayList<File>()
            apks.add(File(ai.sourceDir))
            ai.splitSourceDirs?.forEach { apks.add(File(it)) }
            if (apks.any { !it.canRead() }) return null
            val total = apks.sumOf { it.length() }.coerceAtLeast(1L)

            val displayName = "$safeLabel$EXT"
            val zf = File(tmpDir, "pack_${System.nanoTime()}$EXT")
            zipFile = zf
            var done = 0L
            ZipOutputStream(FileOutputStream(zf).buffered(1 shl 20)).use { zos ->
                zos.setLevel(0) // APKs are already compressed
                val meta = JSONObject()
                    .put("package", pkg)
                    .put("label", label)
                    .put("versionName", info.versionName ?: "")
                    .put("apkCount", apks.size)
                zos.putNextEntry(ZipEntry("meta.json"))
                zos.write(meta.toString().toByteArray())
                zos.closeEntry()
                val buf = ByteArray(1 shl 18)
                for ((i, apk) in apks.withIndex()) {
                    zos.putNextEntry(ZipEntry(if (i == 0) "base.apk" else "split_$i.apk"))
                    apk.inputStream().use { ins ->
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            zos.write(buf, 0, n)
                            done += n
                            onProgress((done.toFloat() / total).coerceAtMost(0.9f))
                        }
                    }
                    zos.closeEntry()
                }
            }

            val ok = VaultManager.addToVault(
                ctx, Uri.fromFile(zf), displayName, VaultManager.APPS_FOLDER, encrypt = true
            )
            if (!ok) return null

            // The vault may have renamed it ("Name (1).apks") if one already existed; find the newest matching file.
            val stored = VaultManager.listFiles(ctx, VaultManager.APPS_FOLDER)
                .filter { VaultManager.displayName(it).startsWith(safeLabel) }
                .maxByOrNull { it.lastModified() } ?: return null
            val storedName = VaultManager.displayName(stored)
            prefs(ctx).edit().putString(storedName, pkg).apply()
            try {
                FileOutputStream(iconFile(ctx, storedName)).use { toBitmap(pm.getApplicationIcon(ai)).compress(Bitmap.CompressFormat.PNG, 100, it) }
            } catch (_: Throwable) {
            }
            onProgress(1f)
            return storedName
        } catch (_: Throwable) {
            return null
        } finally {
            zipFile?.delete()
        }
    }

    // ---------------------------------------------------------------------------------------------
    // 2. Ask Android to uninstall (always shows Android's own confirmation)
    // ---------------------------------------------------------------------------------------------

    fun requestUninstall(activity: Activity, pkg: String) {
        val i = Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg"))
        activity.startActivity(i)
    }

    // ---------------------------------------------------------------------------------------------
    // 3. Install from the vault
    // ---------------------------------------------------------------------------------------------

    /** False when the person still has to allow this app to install apps (Android's "Install unknown apps" switch). */
    fun canInstall(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.O || ctx.packageManager.canRequestPackageInstalls()

    fun openInstallSettings(activity: Activity) {
        val i = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${activity.packageName}"))
        activity.startActivity(i)
    }

    /**
     * Streams the APKs of [vaultFile] into an Android install session. Android then shows its install
     * confirmation. [done] is called on the main thread with (success, message).
     */
    fun install(activity: Activity, vaultFile: File, beforeConfirm: () -> Unit, done: (Boolean, String?) -> Unit) {
        Thread {
            var sessionId = -1
            val pi = activity.packageManager.packageInstaller
            try {
                val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
                sessionId = pi.createSession(params)
                val action = "${activity.packageName}.HIDDEN_APP_INSTALL.$sessionId"
                var wrote = 0
                pi.openSession(sessionId).use { session ->
                    ZipInputStream(VaultManager.openStream(vaultFile).buffered(1 shl 18)).use { zin ->
                        while (true) {
                            val e = zin.nextEntry ?: break
                            if (!e.name.endsWith(".apk")) continue
                            session.openWrite(e.name, 0, -1).use { out ->
                                zin.copyTo(out, 1 shl 18)
                                session.fsync(out)
                            }
                            wrote++
                        }
                    }
                    if (wrote == 0) throw IllegalStateException("No APK inside this file")

                    val receiver = object : BroadcastReceiver() {
                        override fun onReceive(c: Context, intent: Intent) {
                            when (intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)) {
                                PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                                    val confirm: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                                        intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
                                    } else {
                                        @Suppress("DEPRECATION") intent.getParcelableExtra(Intent.EXTRA_INTENT)
                                    }
                                    if (confirm != null) {
                                        beforeConfirm()
                                        activity.startActivity(confirm)
                                    }
                                }
                                PackageInstaller.STATUS_SUCCESS -> {
                                    try { activity.unregisterReceiver(this) } catch (_: Exception) {}
                                    done(true, null)
                                }
                                else -> {
                                    try { activity.unregisterReceiver(this) } catch (_: Exception) {}
                                    val msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE)
                                    done(false, msg)
                                }
                            }
                        }
                    }
                    // Registering a receiver and committing are both fine from this worker thread; the receiver's
                    // callbacks arrive on the main thread.
                    ContextCompat.registerReceiver(activity, receiver, IntentFilter(action), ContextCompat.RECEIVER_NOT_EXPORTED)
                    val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                        (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
                    val pending = PendingIntent.getBroadcast(
                        activity, sessionId, Intent(action).setPackage(activity.packageName), flags
                    )
                    try {
                        session.commit(pending.intentSender)
                    } catch (e: Exception) {
                        try { activity.unregisterReceiver(receiver) } catch (_: Exception) {}
                        activity.runOnUiThread { done(false, e.message) }
                    }
                }
            } catch (e: Throwable) {
                if (sessionId >= 0) try { pi.abandonSession(sessionId) } catch (_: Exception) {}
                activity.runOnUiThread { done(false, e.message) }
            }
        }.start()
    }

    fun launch(activity: Activity, pkg: String): Boolean {
        val i = activity.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        return try {
            activity.startActivity(i)
            true
        } catch (_: Exception) {
            false
        }
    }
}
