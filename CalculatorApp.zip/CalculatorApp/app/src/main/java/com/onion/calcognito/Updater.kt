package com.onion.calcognito

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean

/**
 * In-app updates from the project's GitHub releases.
 *
 *  1. [check] asks the GitHub API for the latest release and compares its tag (for example "v1.6") with the
 *     installed versionName. If it is newer and has an .apk attached, you get an [UpdateInfo].
 *  2. [download] saves that APK in the app's cache folder (with progress) and checks that it really is this app and
 *     really is newer.
 *  3. [install] hands the APK to Android's package installer. Android shows its own "Update this app?" screen; this
 *     needs the "Install unknown apps" switch ([HiddenApps.canInstall]). Android only accepts the update when it is
 *     signed with the same key as the installed app, so release APKs must be signed with that key.
 *
 * Nothing here runs silently: the person always sees the update dialog and Android's confirmation.
 */
object Updater {
    const val RELEASES_API = "https://api.github.com/repos/AryanKumar1234/CalCognito/releases/latest"
    const val RELEASES_PAGE = "https://github.com/AryanKumar1234/CalCognito/releases/"

    class UpdateInfo(val version: String, val notes: String, val apkUrl: String, val size: Long)

    sealed class CheckResult {
        class Available(val info: UpdateInfo) : CheckResult()
        object UpToDate : CheckResult()
        class Failed(val message: String) : CheckResult()
    }

    private val main = Handler(Looper.getMainLooper())
    private const val TAG_DIR = "update"

    // ---------------------------------------------------------------------------------------------
    // 1. Check
    // ---------------------------------------------------------------------------------------------

    /** [done] is always called on the main thread. */
    fun check(ctx: Context, currentVersion: String, done: (CheckResult) -> Unit) {
        val app = ctx.applicationContext
        Thread {
            val result: CheckResult = try {
                clearDownloads(app)
                val conn = open(RELEASES_API)
                conn.setRequestProperty("Accept", "application/vnd.github+json")
                try {
                    when (val code = conn.responseCode) {
                        200 -> parseRelease(conn.inputStream.bufferedReader().use { it.readText() }, currentVersion)
                        404 -> CheckResult.Failed("No releases published yet")
                        403, 429 -> CheckResult.Failed("GitHub is limiting requests right now. Try again later.")
                        else -> CheckResult.Failed("GitHub answered with error $code")
                    }
                } finally {
                    conn.disconnect()
                }
            } catch (e: java.net.UnknownHostException) {
                CheckResult.Failed("No internet connection")
            } catch (e: java.net.SocketTimeoutException) {
                CheckResult.Failed("The connection timed out")
            } catch (e: Exception) {
                CheckResult.Failed(e.message ?: "Something went wrong")
            }
            main.post { done(result) }
        }.start()
    }

    private fun parseRelease(json: String, currentVersion: String): CheckResult {
        val o = JSONObject(json)
        val tag = o.optString("tag_name").ifBlank { o.optString("name") }
        val remote = parseVersion(tag) ?: return CheckResult.Failed("Latest release has no version number ($tag)")
        val local = parseVersion(currentVersion) ?: listOf(0)
        if (compare(remote, local) <= 0) return CheckResult.UpToDate

        val assets = o.optJSONArray("assets")
        var apkUrl: String? = null
        var size = -1L
        if (assets != null) {
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name").endsWith(".apk", ignoreCase = true)) {
                    apkUrl = a.optString("browser_download_url")
                    size = a.optLong("size", -1L)
                    break
                }
            }
        }
        if (apkUrl.isNullOrBlank() || !isTrustedUrl(apkUrl)) {
            return CheckResult.Failed("Version ${tag.trimStart('v', 'V')} exists, but has no APK attached")
        }
        return CheckResult.Available(
            UpdateInfo(tag.trim().trimStart('v', 'V'), o.optString("body").trim(), apkUrl, size)
        )
    }

    /** "v1.6.2" -> [1, 6, 2]; null when there is no digit at all. */
    private fun parseVersion(s: String): List<Int>? {
        val parts = Regex("\\d+").findAll(s).mapNotNull { it.value.toIntOrNull() }.toList()
        return parts.ifEmpty { null }
    }

    private fun compare(a: List<Int>, b: List<Int>): Int {
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }
            val y = b.getOrElse(i) { 0 }
            if (x != y) return x.compareTo(y)
        }
        return 0
    }

    /** Only https downloads from GitHub itself are accepted. */
    private fun isTrustedUrl(url: String): Boolean {
        val u = Uri.parse(url)
        val host = u.host ?: return false
        return u.scheme == "https" &&
            (host == "github.com" || host.endsWith(".github.com") || host.endsWith(".githubusercontent.com"))
    }

    private fun open(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000
        c.readTimeout = 20_000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "CalCognito-Updater")
        return c
    }

    // ---------------------------------------------------------------------------------------------
    // 2. Download
    // ---------------------------------------------------------------------------------------------

    private fun downloadDir(ctx: Context) = File(ctx.cacheDir, TAG_DIR)

    private fun clearDownloads(ctx: Context) {
        downloadDir(ctx).listFiles()?.forEach { it.delete() }
    }

    /**
     * Downloads the APK. [onProgress] gets 0..1 (or -1 when the size is unknown); [done] gets the file, or null
     * plus an error message (also null message when [cancelled] was set). Both are called on the main thread.
     */
    fun download(
        ctx: Context, info: UpdateInfo, cancelled: AtomicBoolean,
        onProgress: (Float) -> Unit, done: (File?, String?) -> Unit
    ) {
        val app = ctx.applicationContext
        Thread {
            var file: File? = null
            var error: String? = null
            try {
                val dir = downloadDir(app).apply { mkdirs() }
                clearDownloads(app)
                val out = File(dir, "CalCognito-${info.version}.apk")
                val conn = open(info.apkUrl)
                try {
                    if (conn.responseCode != 200) throw IllegalStateException("Download failed (${conn.responseCode})")
                    // Redirects must stay on GitHub too.
                    if (!isTrustedUrl(conn.url.toString())) throw IllegalStateException("Unexpected download address")
                    val total = conn.contentLengthLong.takeIf { it > 0 } ?: info.size
                    var read = 0L
                    var lastPost = 0L
                    conn.inputStream.use { input ->
                        FileOutputStream(out).use { fos ->
                            val buf = ByteArray(1 shl 16)
                            while (true) {
                                if (cancelled.get()) break
                                val n = input.read(buf)
                                if (n < 0) break
                                fos.write(buf, 0, n)
                                read += n
                                val now = System.currentTimeMillis()
                                if (now - lastPost > 100) {
                                    lastPost = now
                                    val f = if (total > 0) (read.toFloat() / total).coerceIn(0f, 1f) else -1f
                                    main.post { onProgress(f) }
                                }
                            }
                        }
                    }
                    if (cancelled.get()) {
                        out.delete()
                    } else {
                        if (total > 0 && read != total) throw IllegalStateException("Download was incomplete")
                        verify(app, out)
                        file = out
                    }
                } finally {
                    conn.disconnect()
                }
            } catch (e: java.net.UnknownHostException) {
                error = "No internet connection"
            } catch (e: Exception) {
                error = e.message ?: "Download failed"
            }
            if (file == null) clearDownloads(app)
            val f = file
            val msg = if (cancelled.get()) null else error
            main.post { done(f, msg) }
        }.start()
    }

    /** The downloaded file must be a readable APK of this very app, and newer than the installed copy. */
    private fun verify(ctx: Context, apk: File) {
        val pm = ctx.packageManager
        @Suppress("DEPRECATION")
        val archive = pm.getPackageArchiveInfo(apk.absolutePath, 0)
            ?: throw IllegalStateException("The downloaded file is not a valid APK")
        if (archive.packageName != ctx.packageName) throw IllegalStateException("The APK belongs to a different app")
        @Suppress("DEPRECATION")
        val installed = pm.getPackageInfo(ctx.packageName, 0)
        fun code(p: android.content.pm.PackageInfo): Long =
            if (Build.VERSION.SDK_INT >= 28) p.longVersionCode else @Suppress("DEPRECATION") p.versionCode.toLong()
        if (code(archive) <= code(installed)) throw IllegalStateException("The APK is not newer than the installed app")
    }

    // ---------------------------------------------------------------------------------------------
    // 3. Install
    // ---------------------------------------------------------------------------------------------

    /**
     * Streams [apk] into an install session. Android then shows its install confirmation ([beforeConfirm] runs just
     * before it opens). If the update succeeds Android restarts the app, so [done] mostly matters for failures.
     * [done] is called on the main thread with (success, message).
     */
    fun install(activity: Activity, apk: File, beforeConfirm: () -> Unit, done: (Boolean, String?) -> Unit) {
        Thread {
            var sessionId = -1
            val pi = activity.packageManager.packageInstaller
            try {
                val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
                params.setAppPackageName(activity.packageName)
                sessionId = pi.createSession(params)
                val action = "${activity.packageName}.SELF_UPDATE.$sessionId"
                pi.openSession(sessionId).use { session ->
                    apk.inputStream().use { input ->
                        session.openWrite("update.apk", 0, apk.length()).use { out ->
                            input.copyTo(out, 1 shl 18)
                            session.fsync(out)
                        }
                    }
                    val receiver = object : BroadcastReceiver() {
                        override fun onReceive(c: Context, intent: Intent) {
                            when (intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE)) {
                                PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                                    val confirm: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                                        intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
                                    } else {
                                        @Suppress("DEPRECATION") intent.getParcelableExtra(Intent.EXTRA_INTENT)
                                    }
                                    if (confirm != null) {
                                        beforeConfirm()
                                        activity.startActivity(confirm)
                                    }
                                }
                                PackageInstaller.STATUS_SUCCESS -> {
                                    try { activity.unregisterReceiver(this) } catch (_: Exception) {}
                                    done(true, null)
                                }
                                PackageInstaller.STATUS_FAILURE_ABORTED -> {
                                    // The person backed out of Android's screen: not an error worth shouting about.
                                    try { activity.unregisterReceiver(this) } catch (_: Exception) {}
                                    done(false, null)
                                }
                                else -> {
                                    try { activity.unregisterReceiver(this) } catch (_: Exception) {}
                                    done(false, intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE))
                                }
                            }
                        }
                    }
                    ContextCompat.registerReceiver(
                        activity, receiver, IntentFilter(action), ContextCompat.RECEIVER_NOT_EXPORTED
                    )
                    val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                        (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
                    val pending = PendingIntent.getBroadcast(
                        activity, sessionId, Intent(action).setPackage(activity.packageName), flags
                    )
                    try {
                        session.commit(pending.intentSender)
                    } catch (e: Exception) {
                        try { activity.unregisterReceiver(receiver) } catch (_: Exception) {}
                        main.post { done(false, e.message) }
                    }
                }
            } catch (e: Throwable) {
                if (sessionId >= 0) try { pi.abandonSession(sessionId) } catch (_: Exception) {}
                main.post { done(false, e.message) }
            }
        }.start()
    }
}
