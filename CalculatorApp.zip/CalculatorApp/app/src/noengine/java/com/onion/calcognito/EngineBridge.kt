package com.onion.calcognito

import android.content.Context

/** Used when no engine AAR is in app/libs: hiding apps is reported as unavailable, everything else works. */
object EngineBridge {
    val available: Boolean get() = false
    fun attach(base: Context) {}
    fun create() {}
    fun isInstalled(pkg: String, userId: Int) = false
    fun install(pkg: String, userId: Int) = false
    fun launch(ctx: Context, pkg: String, userId: Int) = false
    fun uninstall(pkg: String, userId: Int) = false
}
